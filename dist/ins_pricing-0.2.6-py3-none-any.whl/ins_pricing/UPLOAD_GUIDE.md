# PyPI 上传指南

## 问题诊断

你遇到的错误 `BadZipFile: File is not a zip file` 通常由以下原因引起:

1. **dist 目录包含旧的或损坏的文件**
2. **使用了通配符 `dist/*` 可能匹配到非包文件**
3. **构建过程不完整或失败**

## 解决方案

### 步骤 1: 清理旧文件

```bash
# Windows (PowerShell 或 CMD)
cd e:\learning\SynologyDrive\Programming\Code\python\ins_pricing
rmdir /s /q dist build Ins_Pricing.egg-info

# Linux/Mac
cd /path/to/ins_pricing
rm -rf dist build *.egg-info
```

### 步骤 2: 重新构建包

```bash
# 确保安装了 build 工具
pip install --upgrade build twine

# 重新构建
python -m build
```

这将在 `dist/` 目录创建两个文件:
- `ins_pricing-0.2.5-py3-none-any.whl` (wheel 文件)
- `ins_pricing-0.2.5.tar.gz` (源码分发)

### 步骤 3: 验证文件完整性

```bash
# 验证 wheel 文件
python -c "import zipfile; z = zipfile.ZipFile('dist/ins_pricing-0.2.5-py3-none-any.whl'); print(f'Valid: {len(z.namelist())} files'); z.close()"

# 验证 tar.gz 文件
python -c "import tarfile; t = tarfile.open('dist/ins_pricing-0.2.5.tar.gz'); print(f'Valid: {len(t.getnames())} files'); t.close()"
```

### 步骤 4: 上传到 PyPI

**方法 A: 使用上传脚本 (推荐)**

```bash
# Windows
set TWINE_PASSWORD=your_pypi_token_here
upload_to_pypi.bat

# Linux/Mac
export TWINE_PASSWORD=your_pypi_token_here
bash upload_to_pypi.sh
```

**方法 B: 手动上传 (明确指定文件)**

```bash
# Windows
python -m twine upload -r pypi -u __token__ -p "%TWINE_PASSWORD%" dist/ins_pricing-0.2.5-py3-none-any.whl dist/ins_pricing-0.2.5.tar.gz

# Linux/Mac
python -m twine upload -r pypi -u __token__ -p "$TWINE_PASSWORD" dist/ins_pricing-0.2.5-py3-none-any.whl dist/ins_pricing-0.2.5.tar.gz
```

**关键点**:
- ✅ 明确指定两个文件 (不使用通配符 `*`)
- ✅ 确保文件名准确匹配
- ✅ 先验证文件完整性

## 常见错误及解决方法

### 错误 1: `BadZipFile: File is not a zip file`

**原因**: dist 目录包含损坏或非 zip 文件

**解决**:
```bash
# 清理并重建
rm -rf dist build *.egg-info
python -m build
```

### 错误 2: `HTTPError: 403 Forbidden`

**原因**: PyPI token 无效或版本号已存在

**解决**:
1. 检查 TWINE_PASSWORD 是否正确
2. 更新 setup.py 和 pyproject.toml 中的版本号
3. 确保使用的是 PyPI API token (以 `pypi-` 开头)

### 错误 3: `File already exists`

**原因**: 该版本已上传到 PyPI

**解决**:
```python
# 更新版本号
# 编辑 setup.py
version="0.2.6"  # 增加版本号

# 编辑 pyproject.toml
version = "0.2.6"

# 重新构建
python -m build
```

### 错误 4: `No such file or directory: dist/...`

**原因**: 构建失败或文件名不匹配

**解决**:
```bash
# 检查实际文件名
ls dist/

# 确保构建成功
python -m build 2>&1 | grep -i error
```

## 版本管理

当前版本: **0.2.5**

更新版本时需要修改两个文件:

1. **setup.py** (line 23)
   ```python
   version="0.2.5",
   ```

2. **pyproject.toml** (line 6)
   ```toml
   version = "0.2.5"
   ```

## 验证上传成功

上传成功后:

```bash
# 等待 1-2 分钟让 PyPI 索引更新

# 在新环境中测试安装
pip install --upgrade ins-pricing==0.2.5

# 验证版本
python -c "import ins_pricing; print(ins_pricing.__version__ if hasattr(ins_pricing, '__version__') else 'Version not set')"
```

## 安全提示

1. **永远不要在代码中硬编码 PyPI token**
2. **使用环境变量存储敏感信息**
3. **定期轮换 API token**
4. **为不同项目使用不同的 token (如果可能)**

## 故障排除清单

- [ ] 清理了 dist, build, *.egg-info 目录
- [ ] 成功运行了 `python -m build`
- [ ] dist/ 目录包含恰好 2 个文件
- [ ] 验证了 wheel 文件完整性
- [ ] 验证了 tar.gz 文件完整性
- [ ] 设置了 TWINE_PASSWORD 环境变量
- [ ] 使用明确的文件名 (不使用 `*`)
- [ ] 版本号已更新 (如果重新上传)

## 联系支持

如果问题仍然存在:

1. 检查 [PyPI 状态页](https://status.python.org/)
2. 查看 [twine 文档](https://twine.readthedocs.io/)
3. 检查 [setuptools 文档](https://setuptools.pypa.io/)

---

**最后更新**: 2026-01-14
**适用版本**: ins_pricing 0.2.5
